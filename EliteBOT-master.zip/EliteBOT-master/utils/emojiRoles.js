module.exports = [{
        emoji: '🇦',
        roleId: '622941407509741589', // C
    },
    {
        emoji: '🇧',
        roleId: '627548272885760021', // C++
    },
    {
        emoji: '🇨',
        roleId: '627548355173548042' // C#
    },
    {
        emoji: '🇩',
        roleId: '627547764708081665' // Rust
    },
    {
        emoji: '🇪',
        roleId: '622941463487053835' // Java
    },
    {
        emoji: '🇫',
        roleId: '622941592759566337' // Kotlin
    },
    {
        emoji: '🇬',
        roleId: '622941651257655308' // GO
    },
    {
        emoji: '🇭',
        roleId: '622941668521410581' // HTML
    },
    {
        emoji: '🇮',
        roleId: '622941753875628053' // CSS
    },
    {
        emoji: '🇯',
        roleId: '622941569384972308' // Javascript
    },
    {
        emoji: '🇰',
        roleId: '622941618445615117' // PHP
    }
];