const configFile = require('./comandos/config.json');

// TODO - Configuration valitation and parsing.

module.exports = configFile;